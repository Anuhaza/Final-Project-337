const url = '/orderHistory';
const cookieString = document.cookie;
const cookieValue = cookieString.split('=')[1];
const loginData = JSON.parse(decodeURIComponent(cookieValue));

fetch(url + '/' + loginData.username)
.then(response => response.json())
.then(data => {
	data.forEach(order => {
            const orderBox = document.createElement('div');
            orderBox.classList.add('order-box');

            const orderDate = document.createElement('div');
            orderDate.classList.add('order-date');
            orderDate.textContent = 'Order Date: ' + order.orderDate;

            const orderTable = document.createElement('table');
		orderHTML = '
		  <thead>
                <tr>
                  <th>Item Name</th>
                  <th>Quantity</th>
                  <th>Price</th>
                </tr>
              </thead>
              <tbody>';

		sum = 0;

		order.items.forEach(itemId => {
			 fetch('/items/' + itemId)
    			.then(response => response.json())
    			.then(item => {
      			orderHTML = orderHTML + '<tr>
                    		<td>${item.title}</td>
                    		<td>1</td>
                   		 <td>${item.price}</td>
                  	</tr>'
				sum = sum + item.price;
    			})
    			.catch(error => console.error(error));
		};

		orderHTML = orderHTML + '</tbody>';
		orderTable.innerHTML = orderHTML;

		const orderTotal = document.createElement('div');
            orderTotal.classList.add('order-total');

		orderTotal.textContent = 'Total Price: ${sum}';
})
.catch(error => console.error(error));
		