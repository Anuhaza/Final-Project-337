function termsAndConditions() {
  var modal = document.getElementById("modal");
  var span = document.getElementsByClassName("close")[0];
  modal.style.display = "block";
  span.onclick = function() {
	modal.style.display = "none";
  }
}

function login() {
  const username1 = document.getElementById('username').value;
  const password1 = document.getElementById('password').value;

  fetch('/login/' + username1 + '/' + password1)
  .then(response => response.text())
  .then(data => {
    if (data == "success") {
      window.location.href = '/menu'; //redirect.
    } else {
      document.getElementById('message').innerHTML = 'Login failed.';
    }
  })
  .catch(error => {
    alert('An error occurred during login.');
  });
}

function createAccount() {
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  const user = {
    username: username,
    password: password
  };

  fetch('/add/user', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(user)
  })
  .then(response => response.text())
  .then(data => {
     if (data == "success") {
      window.location.href = '/menu'; //redirect.
    } else {
      document.getElementById('message').innerHTML = data;
    }
  })
  .catch(error => {
    console.error(error);
  });

}