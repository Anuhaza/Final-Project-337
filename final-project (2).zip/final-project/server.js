const express = require("express");
const mongoose = require("mongoose");

const PORT = 5000;
const DB_URL = "mongodb://127.0.0.1:27017/foi";

const app = express();

app.use(express.static("public"));
app.set("view engine", "ejs");

app.get("/", (req, res) => {
  res.render("index");
});

app.get("/menu", (req, res) => {
  res.render("menu", {});
});

app.get("/login", (req, res) => {
  res.render("login", {});
});

app.get("/faq", (req, res) => {
  res.render("faq", {});
});

app.get("/orderHistory", (req, res) => {
  res.render("orderHistory", {});
});

mongoose
  .connect(DB_URL)
  .then(() => console.log("Connected to Database"))
  .catch((err) => console.log("Error", err));

app.listen(5000, () => console.log(`app running on http://localhost:${PORT}/`));
