const mongoose = require("mongoose");

const UserSchema = new mongoose.Schema({
  username: String,
  email: String,
  password: String,
  currentOrder: { items: [], total: Number },
});

const ItemSchema = new mongoose.Schema({
  title: String,
  description: String,
  price: Number,
  image: String,
});

const OrderSchema = new mongoose.Schema({
  userId: String,
  username: String,
  items: [],
  total: Number,
  status: String,
  type: String,
  paid: Boolean,
  payment: {
    cardNo: Number,
    cvv: Number,
    exp: String,
  },
});

export const User = mongoose.model("user", UserSchema);
export const Item = mongoose.model("item", ItemSchema);
export const Order = mongoose.model("order", OrderSchema);
