// Function to handle form submission
async function makeReservation(event) {
  event.preventDefault();
  const time = document.getElementById("time").value;
  const noOfPersons = document.getElementById("noOfPersons").value;
  const phone = document.getElementById("phone").value;
  const date = document.getElementById("date").value;

  // Send reservation data to server
  const response = await fetch("/api/reservation", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ time, noOfPersons, phone, date })
  });
  const data = await response.json();
  if (data.ok) {
    alert("Reservation made successfully!");
  } else {
    alert(data.message);
  }
}

// Client-side JavaScript code

async function viewReservations() {
  const response = await fetch("/api/reservations");
  const data = await response.json();
  if (!data.ok) {
    alert(data.message);
  } else {
    // Get the reservations container element
    const reservationsContainer = document.getElementById("reservationsContainer");

    // Clear any existing reservations
    reservationsContainer.innerHTML = "";

    // Loop through each reservation and create a reservation element
    data.reservations.forEach(reservation => {
      // Create a reservation element
      const reservationElement = document.createElement("div");
      reservationElement.className = "reservation";

      // Display reservation information in the element
      reservationElement.innerHTML = `
        <p>Time: ${reservation.time}</p>
        <p>Party Size: ${reservation.noOfPersons}</p>
        <p>Phone: ${reservation.phone}</p>
        <p>Date: ${reservation.date}</p>
      `;

      // Append the reservation element to the reservations container
      reservationsContainer.appendChild(reservationElement);
    });
  }
}
// Add event listener for form submission
document.getElementById("reservationForm").addEventListener("submit", makeReservation);

// Add event listener for button click
document.getElementById("viewReservationsBtn").addEventListener("click", viewReservations);
