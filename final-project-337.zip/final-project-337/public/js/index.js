const contactUsButton = document.getElementById("contactUsButton");
const nameAbout = document.getElementById("nameAbout");
const nameAboutText = document.getElementById("nameAboutText");
const messageAbout = document.getElementById("messageAbout");
const messageAboutText = document.getElementById("messageAboutText");
const contactForm = document.getElementById("contactForm");
const successEl = document.getElementById("success");

// // Hide the form initially
// nameAboutText.style.display = "none";
// messageAboutText.style.display = "none";
// nameAbout.style.display = "none";
// messageAbout.style.display = "none";
// messageAbout.style.display = "none";
// submitButton.style.display = "none";

// // Show the form when the button is clicked
// contactUsButton.addEventListener("click", () => {
//   nameAboutText.style.display = "block";
//   messageAboutText.style.display = "block";
//   nameAbout.style.display = "block";
//   messageAbout.style.display = "block";
//   submitButton.style.display = "block";
//   contactUsButton.style.display = "none";
// });

async function sendMessage(e) {
  e.preventDefault();
  const body = {
    name: nameAboutText.value,
    text: messageAboutText.value,
  };
  console.log("data", body);

  try {
    const res = await fetch("/api/message", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (data.ok) {
      successEl.style.display = "block";
      successEl.textContent = "Thank you for your message";
      contactForm.reset();
      setTimeout(() => (successEl.style.display = "none"), 5000);
    } else {
      alert("else Error: unable to send message");
    }
  } catch (e) {
    console.log(e);
    alert("Error: unable to send message");
  }
}

contactForm.addEventListener("submit", sendMessage);
