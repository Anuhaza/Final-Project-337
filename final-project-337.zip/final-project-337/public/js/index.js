const contactUsButton = document.getElementById("contactUsButton");
const nameAbout = document.getElementById("nameAbout");
const nameAboutText = document.getElementById("nameAboutText");
const messageAbout = document.getElementById("messageAbout");
const messageAboutText = document.getElementById("messageAboutText");

// Hide the form initially
nameAboutText.style.display = "none";
messageAboutText.style.display = "none";
nameAbout.style.display = "none";
messageAbout.style.display = "none";
messageAbout.style.display = "none";
submitButton.style.display = "none";

// Show the form when the button is clicked
contactUsButton.addEventListener("click", () => {
  nameAboutText.style.display = "block";
  messageAboutText.style.display = "block";
  nameAbout.style.display = "block";
  messageAbout.style.display = "block";
  submitButton.style.display = "block";
  contactUsButton.style.display = "none";
});
